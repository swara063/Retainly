# Dataset Strategy

## Primary Dataset
IBM HR Attrition Dataset

## Secondary Dataset
Kaggle HR Analytics Dataset

## Custom Dataset Support
- Column mapping system
- Validation checks

## Constraints
- Structured tabular data only
