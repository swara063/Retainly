# System Architecture

## Architecture Layers

1. Presentation Layer (React Frontend)
2. Application Layer (FastAPI Backend)
3. Processing Layer (Agents)
4. ML Layer (Scikit-learn)
5. Insight Layer (LLM + Explainability)

## Data Flow

User Upload → Backend → Column Mapper → Agents → Results → UI

## Agent Interaction

Project Manager → Data Analyst → ML Engineer → Insights Agent

Each agent performs a modular task and passes output to the next.
