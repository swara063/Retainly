# Fairness and Ethics

## Bias Checks
- Gender bias
- Age bias

## Metrics
- Prediction rate differences
- False positive rate comparison

## Ethical Principles
- Transparency
- No automated decision-making
- User disclaimer included

## Output
Bias levels: Low / Moderate / High
