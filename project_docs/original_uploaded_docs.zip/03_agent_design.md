# Multi-Agent System Design

## 1. Project Manager Agent
- Controls workflow execution
- Initializes pipeline
- Logs progress

## 2. Data Analyst Agent
- Data cleaning
- Missing value handling
- Exploratory Data Analysis

## 3. ML Engineer Agent
- Feature engineering
- Model training
- Model selection

## 4. Insights Agent
- Feature importance
- Insight generation
- Report synthesis

## Design Principle
Agents are modular services, not conversational bots.
