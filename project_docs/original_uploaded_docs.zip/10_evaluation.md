# Evaluation Strategy

## Metrics
- Accuracy
- Precision, Recall
- F1 Score

## Fairness Evaluation
- Bias across demographics

## Performance
- Execution time
- System stability

## Validation
- Tested on multiple datasets
