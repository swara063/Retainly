# API Design

## POST /upload
Uploads dataset

## POST /analyze
Triggers full pipeline

## GET /results/{id}
Returns EDA, model results, insights

## GET /logs/{id}
Returns agent execution logs

## GET /report/{id}
Downloads PDF report

## Design Principle
Stateless APIs with dataset ID tracking
